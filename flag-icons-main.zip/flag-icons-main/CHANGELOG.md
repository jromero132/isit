# 6.4.3

- Fix flag of Argentina

# 6.4.2

- Convert text to path in flags: **sm**, **gu**.

# 6.4.1

- Added flag for Central European Free Trade Agreement ([CEFTA](https://en.wikipedia.org/wiki/Central_European_Free_Trade_Agreement))
